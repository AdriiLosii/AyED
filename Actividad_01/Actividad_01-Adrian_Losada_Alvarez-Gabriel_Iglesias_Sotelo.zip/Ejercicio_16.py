"""
Programa: Ejercicio_16.py
Propósito:
    ¿Puedes mejorar el algoritmo del problema anterior para que sea lineal? Explica.
Fecha:01/02/2022
Autores:Adrián Losada Álvarez y Gabriel Iglesias Sotelo
"""


"""
Dicho algoritmo no se puede simplicar para que sea lineal, ya que para ello la lista tendría que estar ordenada desde 
un principio, en tal caso sería un algoritmo O(1).
"""